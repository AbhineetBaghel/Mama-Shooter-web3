gdjs.startCode = {};
gdjs.startCode.GDFloorSpikesObjects1= [];
gdjs.startCode.GDFloorSpikesObjects2= [];
gdjs.startCode.GDtitleObjects1= [];
gdjs.startCode.GDtitleObjects2= [];
gdjs.startCode.GDTile6TiledSpriteObjects1= [];
gdjs.startCode.GDTile6TiledSpriteObjects2= [];
gdjs.startCode.GDTree1Objects1= [];
gdjs.startCode.GDTree1Objects2= [];
gdjs.startCode.GDRock1Objects1= [];
gdjs.startCode.GDRock1Objects2= [];

gdjs.startCode.conditionTrue_0 = {val:false};
gdjs.startCode.condition0IsTrue_0 = {val:false};
gdjs.startCode.condition1IsTrue_0 = {val:false};


gdjs.startCode.eventsList0 = function(runtimeScene) {

{


{
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "", 0);
}}

}


{


gdjs.startCode.condition0IsTrue_0.val = false;
{
gdjs.startCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
}if (gdjs.startCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "game", false);
}}

}


};

gdjs.startCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.startCode.GDFloorSpikesObjects1.length = 0;
gdjs.startCode.GDFloorSpikesObjects2.length = 0;
gdjs.startCode.GDtitleObjects1.length = 0;
gdjs.startCode.GDtitleObjects2.length = 0;
gdjs.startCode.GDTile6TiledSpriteObjects1.length = 0;
gdjs.startCode.GDTile6TiledSpriteObjects2.length = 0;
gdjs.startCode.GDTree1Objects1.length = 0;
gdjs.startCode.GDTree1Objects2.length = 0;
gdjs.startCode.GDRock1Objects1.length = 0;
gdjs.startCode.GDRock1Objects2.length = 0;

gdjs.startCode.eventsList0(runtimeScene);

return;

}

gdjs['startCode'] = gdjs.startCode;
